/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2023, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/**
 * \file
 * \brief Implementation of AffineGradientSearch class
 */

// ====================================================================================================================
// Includes
// ====================================================================================================================

#include "AffineGradientSearch.h"

//! \ingroup CommonLib
//! \{

// ====================================================================================================================
// Private member functions
// ====================================================================================================================

AffineGradientSearch::AffineGradientSearch()
{
  m_EqualCoeffComputer[0] = xEqualCoeffComputer<false>;
  m_EqualCoeffComputer[1] = xEqualCoeffComputer<true>;

#if ENABLE_SIMD_OPT_AFFINE_ME
#ifdef TARGET_SIMD_X86
  initAffineGradientSearchX86();
#endif
#endif
}

template<bool b6Param>
void AffineGradientSearch::xEqualCoeffComputer(Pel *const pResidue, const ptrdiff_t residueStride,
                                               Pel **const ppDerivate, const ptrdiff_t derivateBufStride,
                                               int64_t (*pEqualCoeff)[7], int width, int height, int shift)
{
  int affineParamNum = b6Param ? 6 : 4;

  for (int j = 0; j != height; j++)
  {
    for (int k = 0; k != width; k++)
    {
      int iC[6];

      ptrdiff_t idx = j * derivateBufStride + k;
      if (!b6Param)
      {
        iC[0] = ppDerivate[0][idx];
        iC[1] = k * ppDerivate[0][idx] + j * ppDerivate[1][idx];
        iC[2] = ppDerivate[1][idx];
        iC[3] = j * ppDerivate[0][idx] - k * ppDerivate[1][idx];
      }
      else
      {
        iC[0] = ppDerivate[0][idx];
        iC[1] = k * ppDerivate[0][idx];
        iC[2] = ppDerivate[1][idx];
        iC[3] = k * ppDerivate[1][idx];
        iC[4] = j * ppDerivate[0][idx];
        iC[5] = j * ppDerivate[1][idx];
      }
      for (int col = 0; col < affineParamNum; col++)
      {
        for (int row = 0; row < affineParamNum; row++)
        {
          pEqualCoeff[col + 1][row] += (int64_t)iC[col] * iC[row];
        }
        pEqualCoeff[col + 1][affineParamNum] += (int64_t)iC[col] * pResidue[idx];
      }
    }
  }

  for (int col = 0; col < affineParamNum; col++)
  {
    pEqualCoeff[col + 1][affineParamNum] = pEqualCoeff[col + 1][affineParamNum] >> shift;
  }
}

//! \}
