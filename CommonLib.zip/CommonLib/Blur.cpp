#include "Blur.h"
#include "Unit.h"

#if BLURDEBLUR

#include <cmath>
#include <complex>
#include <cstddef>
#include <cstdint>
#include <stdexcept>
#include <vector>


extern "C"
{
typedef double fftw_complex[2];
typedef struct fftw_plan_s *fftw_plan;

void      *fftw_malloc(size_t n);
void       fftw_free(void *p);
fftw_plan  fftw_plan_dft_2d(int n0, int n1, fftw_complex *in, fftw_complex *out, int sign, unsigned flags);
void       fftw_execute(const fftw_plan p);
void       fftw_destroy_plan(fftw_plan p);
}

namespace
{
constexpr double kSigmaScale = 1000000.0;
constexpr int    kFftForward = -1;
constexpr int    kFftInverse = 1;
constexpr unsigned kFftEstimate = 1U << 6;

inline int reflectIndex(int value, int limit)
{
  if (limit <= 1)
  {
    return 0;
  }

  const int period = 2 * limit - 2;
  int       idx    = value % period;
  if (idx < 0)
  {
    idx += period;
  }

  return idx < limit ? idx : period - idx;
}

inline std::complex<double> loadComplex(const fftw_complex &value)
{
  return { value[0], value[1] };
}

inline void storeComplex(fftw_complex &dst, const std::complex<double> &value)
{
  dst[0] = value.real();
  dst[1] = value.imag();
}
}   // namespace




Blur::Blur(const std::vector<double> &sigmas, int kernelSize) : m_kernelSize(kernelSize)
{
  if (m_kernelSize < 3 || (m_kernelSize & 1) == 0)
  {
    throw std::invalid_argument("kernelSize must be an odd value >= 3");
  }

  registerSigmas(sigmas);
}

void Blur::registerSigma(double sigma)
{
  m_kernelTable.emplace(sigmaToKey(sigma), makeKernel(sigma));
}

void Blur::registerSigmas(const std::vector<double> &sigmas)
{
  for (double sigma : sigmas)
  {
    registerSigma(sigma);
  }
}

bool Blur::hasSigma(double sigma) const
{
  return m_kernelTable.find(sigmaToKey(sigma)) != m_kernelTable.end();
}

void Blur::apply(const Pel *src, ptrdiff_t srcStride, int height, int width, Pel *dst, ptrdiff_t dstStride,
                 double sigma, const ClpRng &clpRng) const
{
  const Kernel &kernel = getKernel(sigma);

  for (int y = 0; y < height; ++y)
  {
    for (int x = 0; x < width; ++x)
    {
      double accum = 0.0;
      for (int ky = -kernel.radius; ky <= kernel.radius; ++ky)
      {
        const int sy = reflectIndex(y + ky, height);
        for (int kx = -kernel.radius; kx <= kernel.radius; ++kx)
        {
          const int sx = reflectIndex(x + kx, width);
          const int kk = (ky + kernel.radius) * m_kernelSize + (kx + kernel.radius);
          accum += kernel.coeff[static_cast<size_t>(kk)] * src[sy * srcStride + sx];
        }
      }

      dst[y * dstStride + x] = static_cast<Pel>(ClipPel<int>(static_cast<int>(std::lround(accum)), clpRng));
    }
  }
}

void Blur::calcResidual(const CPelBuf &org, const CPelBuf &pred, PelBuf &resi, PelBuf &tmpPredBlur, double sigma,
                        const ClpRng &clpRng) const
{
  CHECK(org.width != pred.width || org.height != pred.height, "org/pred size mismatch");
  CHECK(org.width != resi.width || org.height != resi.height, "org/resi size mismatch");
  CHECK(pred.width != tmpPredBlur.width || pred.height != tmpPredBlur.height, "pred/tmpPredBlur size mismatch");

  apply(org.buf, org.stride, org.height, org.width, resi.buf, resi.stride, sigma, clpRng);
  apply(pred.buf, pred.stride, pred.height, pred.width, tmpPredBlur.buf, tmpPredBlur.stride, sigma, clpRng);
  resi.subtract(tmpPredBlur);
}

void Blur::reconstructAndDeblur(const CPelBuf &resi, const CPelBuf &pred, PelBuf &reco, PelBuf &tmpPredBlur,
                                double sigma, const ClpRng &clpRng, double lambda, double dataWeight) const
{
  CHECK(resi.width != pred.width || resi.height != pred.height, "resi/pred size mismatch");
  CHECK(resi.width != reco.width || resi.height != reco.height, "resi/reco size mismatch");
  CHECK(pred.width != tmpPredBlur.width || pred.height != tmpPredBlur.height, "pred/tmpPredBlur size mismatch");

  apply(pred.buf, pred.stride, pred.height, pred.width, tmpPredBlur.buf, tmpPredBlur.stride, sigma, clpRng);
  reco.reconstruct(tmpPredBlur, resi, clpRng);
  deblur(reco.buf, reco.stride, pred.buf, pred.stride, reco.height, reco.width, reco.buf, reco.stride, sigma, clpRng,
         lambda, dataWeight);
}

void Blur::deblur(const Pel *src, ptrdiff_t srcStride, const Pel *guide, ptrdiff_t guideStride, int height, int width,
                  Pel *dst, ptrdiff_t dstStride, double sigma, const ClpRng &clpRng, double lambda,
                  double dataWeight) const
{
  const Kernel      &kernel    = getKernel(sigma);
  const size_t       fftSize   = static_cast<size_t>(height) * width;
  fftw_complex      *kernelPsf = static_cast<fftw_complex *>(fftw_malloc(sizeof(fftw_complex) * fftSize));
  fftw_complex      *kernelOtf = static_cast<fftw_complex *>(fftw_malloc(sizeof(fftw_complex) * fftSize));
  fftw_complex      *yFreq     = static_cast<fftw_complex *>(fftw_malloc(sizeof(fftw_complex) * fftSize));
  fftw_complex      *guideFreq = static_cast<fftw_complex *>(fftw_malloc(sizeof(fftw_complex) * fftSize));
  fftw_complex      *xFreq     = static_cast<fftw_complex *>(fftw_malloc(sizeof(fftw_complex) * fftSize));
  fftw_complex      *spatial   = static_cast<fftw_complex *>(fftw_malloc(sizeof(fftw_complex) * fftSize));

  if (!kernelPsf || !kernelOtf || !yFreq || !guideFreq || !xFreq || !spatial)
  {
    throw std::runtime_error("fftw_malloc failed");
  }

  for (size_t i = 0; i < fftSize; ++i)
  {
    kernelPsf[i][0] = 0.0;
    kernelPsf[i][1] = 0.0;
    yFreq[i][0]     = 0.0;
    yFreq[i][1]     = 0.0;
    guideFreq[i][0] = 0.0;
    guideFreq[i][1] = 0.0;
  }

  for (int ky = 0; ky < m_kernelSize; ++ky)
  {
    for (int kx = 0; kx < m_kernelSize; ++kx)
    {
      const int yy = reflectIndex(ky - kernel.radius, height);
      const int xx = reflectIndex(kx - kernel.radius, width);
      kernelPsf[static_cast<size_t>(yy) * width + xx][0] = kernel.coeff[static_cast<size_t>(ky) * m_kernelSize + kx];
    }
  }

  for (int y = 0; y < height; ++y)
  {
    for (int x = 0; x < width; ++x)
    {
      const size_t idx = static_cast<size_t>(y) * width + x;
      yFreq[idx][0]     = src[y * srcStride + x];
      guideFreq[idx][0] = guide[y * guideStride + x];
    }
  }

  fftw_plan kernelPlan = fftw_plan_dft_2d(height, width, kernelPsf, kernelOtf, kFftForward, kFftEstimate);
  fftw_plan yPlan      = fftw_plan_dft_2d(height, width, yFreq, yFreq, kFftForward, kFftEstimate);
  fftw_plan guidePlan  = fftw_plan_dft_2d(height, width, guideFreq, guideFreq, kFftForward, kFftEstimate);
  fftw_plan invPlan    = fftw_plan_dft_2d(height, width, xFreq, spatial, kFftInverse, kFftEstimate);

  if (!kernelPlan || !yPlan || !guidePlan || !invPlan)
  {
    throw std::runtime_error("failed to create FFTW plan");
  }

  fftw_execute(kernelPlan);
  fftw_execute(yPlan);
  fftw_execute(guidePlan);

  for (size_t i = 0; i < fftSize; ++i)
  {
    const std::complex<double> K = loadComplex(kernelOtf[i]);
    const std::complex<double> Y = loadComplex(yFreq[i]);
    const std::complex<double> R = loadComplex(guideFreq[i]);
    const double               denom = dataWeight * std::norm(K) + lambda;
    const std::complex<double> X = (dataWeight * std::conj(K) * Y + lambda * R) / denom;
    storeComplex(xFreq[i], X);
  }

  fftw_execute(invPlan);

  const double scale = 1.0 / static_cast<double>(fftSize);
  for (int y = 0; y < height; ++y)
  {
    for (int x = 0; x < width; ++x)
    {
      const size_t idx   = static_cast<size_t>(y) * width + x;
      const int    value = static_cast<int>(std::lround(spatial[idx][0] * scale));
      dst[y * dstStride + x] = static_cast<Pel>(ClipPel<int>(value, clpRng));
    }
  }

  fftw_destroy_plan(kernelPlan);
  fftw_destroy_plan(yPlan);
  fftw_destroy_plan(guidePlan);
  fftw_destroy_plan(invPlan);
  fftw_free(kernelPsf);
  fftw_free(kernelOtf);
  fftw_free(yFreq);
  fftw_free(guideFreq);
  fftw_free(xFreq);
  fftw_free(spatial);
}

int64_t Blur::sigmaToKey(double sigma)
{
  return static_cast<int64_t>(std::llround(sigma * kSigmaScale));
}

Blur::Kernel Blur::makeKernel(double sigma) const
{
  if (sigma <= 0.0)
  {
    throw std::invalid_argument("sigma must be positive");
  }

  Kernel kernel;
  kernel.radius = m_kernelSize / 2;
  kernel.coeff.resize(static_cast<size_t>(m_kernelSize) * m_kernelSize, 0.0f);

  double sum = 0.0;
  for (int y = -kernel.radius; y <= kernel.radius; ++y)
  {
    for (int x = -kernel.radius; x <= kernel.radius; ++x)
    {
      const double value = std::exp(-static_cast<double>(x * x + y * y) / (2.0 * sigma * sigma));
      kernel.coeff[static_cast<size_t>(y + kernel.radius) * m_kernelSize + (x + kernel.radius)] =
        static_cast<float>(value);
      sum += value;
    }
  }

  for (float &coeff : kernel.coeff)
  {
    coeff = static_cast<float>(coeff / sum);
  }

  return kernel;
}

const Blur::Kernel &Blur::getKernel(double sigma) const
{
  const auto iter = m_kernelTable.find(sigmaToKey(sigma));
  if (iter == m_kernelTable.end())
  {
    throw std::runtime_error("sigma was not registered");
  }

  return iter->second;
}

#endif
