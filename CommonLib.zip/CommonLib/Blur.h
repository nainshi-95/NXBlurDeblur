/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2023, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

#ifndef BLUR_H
#define BLUR_H


#include "CommonDef.h"

#include <unordered_map>
#include <vector>


#if BLURDEBLUR

template<typename T> struct AreaBuf;
typedef AreaBuf<Pel>       PelBuf;
typedef AreaBuf<const Pel> CPelBuf;




class Blur
{
public:
  explicit Blur(const std::vector<double> &sigmas = {}, int kernelSize = 5);

  void registerSigma(double sigma);
  void registerSigmas(const std::vector<double> &sigmas);
  bool hasSigma(double sigma) const;
  int  kernelSize() const { return m_kernelSize; }

  // src/dst stride unit: number of Pel elements per row.
  void apply(const Pel *src, ptrdiff_t srcStride, int height, int width, Pel *dst, ptrdiff_t dstStride,
             double sigma, const ClpRng &clpRng) const;
  void calcResidual(const CPelBuf &org, const CPelBuf &pred, PelBuf &resi, PelBuf &tmpPredBlur, double sigma,
                    const ClpRng &clpRng) const;
  void reconstructAndDeblur(const CPelBuf &resi, const CPelBuf &pred, PelBuf &reco, PelBuf &tmpPredBlur, double sigma,
                            const ClpRng &clpRng, double lambda = 0.02, double dataWeight = 1.0) const;
  void deblur(const Pel *src, ptrdiff_t srcStride, const Pel *guide, ptrdiff_t guideStride, int height, int width,
              Pel *dst, ptrdiff_t dstStride, double sigma, const ClpRng &clpRng, double lambda = 0.02,
              double dataWeight = 1.0) const;

private:
  struct Kernel
  {
    int                radius = 0;   // radius = kernelSize / 2
    std::vector<float> coeff;
  };

  int                                m_kernelSize = 5;
  std::unordered_map<int64_t, Kernel> m_kernelTable;

  static int64_t sigmaToKey(double sigma);
  Kernel         makeKernel(double sigma) const;
  const Kernel  &getKernel(double sigma) const;
};

#endif   // BLUR_H
#endif
