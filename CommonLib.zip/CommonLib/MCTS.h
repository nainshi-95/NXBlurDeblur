/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2023, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     MCTS.h
    \brief    Motion Constrained Tile Sets class (header)
*/

#ifndef __MCTS__
#define __MCTS__

// Include files

#include "Unit.h"

// forward declaration
class Mv;

//! \ingroup CommonLib
//! \{

// ====================================================================================================================
// Class definition
// ====================================================================================================================
class MCTSInfo
{
private:
  Area m_tileArea;

public:
  MCTSInfo() : m_tileArea(Area(0, 0, 0, 0)) {};

  void init(CodingStructure *cs, int ctuAddr);

  Area        getTileArea() { return m_tileArea; }
  const Area &getTileArea() const { return m_tileArea; }

  Area getTileAreaSubPelRestricted(const CodingUnit &cu);
  Area getTileAreaIntPelRestricted(const CodingUnit &cu);
};

namespace MCTSHelper
{
Area getTileAreaRestricted(const Area &tileArea, const int offLT, const int offRB);
void clipMvToArea(Mv &rcMv, const struct Area &block, const struct Area &clipArea, const SPS &sps,
                  int mvFracBits = MV_FRACTIONAL_BITS_INTERNAL);
Area getTileArea(const CodingStructure *cs, const int ctuAddr);
bool checkMvForMCTSConstraint(const CodingUnit &cu, const Mv &mv, const MvPrecision mvPrec = MvPrecision::QUARTER);
bool checkMvBufferForMCTSConstraint(const CodingUnit &cu, bool msgFlag = false);
bool checkMvIsNotInRestrictedArea(const CodingUnit &cu, const Mv &mv, const Area &restrArea, const MvPrecision mvPrec);
}   // namespace MCTSHelper

//! \}

#endif // __MCTS__
