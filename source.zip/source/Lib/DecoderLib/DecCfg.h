/* The copyright in this software is being made available under the BSD
 * License, included below. This software may be subject to other third party
 * and contributor rights, including patent rights, and no such rights are
 * granted under this license.
 *
 * Copyright (c) 2010-2023, ITU/ISO/IEC
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions are met:
 *
 *  * Redistributions of source code must retain the above copyright notice,
 *    this list of conditions and the following disclaimer.
 *  * Redistributions in binary form must reproduce the above copyright notice,
 *    this list of conditions and the following disclaimer in the documentation
 *    and/or other materials provided with the distribution.
 *  * Neither the name of the ITU/ISO/IEC nor the names of its contributors may
 *    be used to endorse or promote products derived from this software without
 *    specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS
 * BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
 * CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
 * SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
 * INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
 * CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
 * ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF
 * THE POSSIBILITY OF SUCH DAMAGE.
 */

/** \file     DecCfg.h
    \brief    Decoder configuration class (header)
*/

#ifndef __DECCFG__
#define __DECCFG__

#pragma once

#include "CommonLib/CommonDef.h"
#include <vector>

//! \ingroup DecoderLib
//! \{

// ====================================================================================================================
// Class definition
// ====================================================================================================================

/// Decoder configuration class
struct DecCfg
{
  std::string                m_bitstreamFileName { "" };    // input bitstream file name
  std::string                m_reconFileName { "" };    // output reconstruction file name
  std::string                m_oplFilename { "" };    // filename to output conformance log.
  int                        m_iSkipFrame { 0 };     // counter for frames prior to the random access point to skip
  BitDepths                  m_outputBitDepth { 0, 0 };  // bit depth used for writing output
  InputColourSpaceConversion m_outputColourSpaceConvert { IPCOLOURSPACE_UNCHANGED };
  int                        m_targetOlsIdx { 500 };   // target output layer set
  int                        m_iMaxTemporalLayer { 500 };   // maximum temporal layer to be decoded
  bool                       m_mTidExternalSet { false }; // maximum temporal layer set externally
  bool                       m_tOlsIdxTidExternalSet { false }; // target output layer set index externally set
  int                        m_decodedPictureHashSEIEnabled {
    2
  };     // Checksum(3)/CRC(2)/MD5(1)/disable(0) acting on decoded picture hash SEI message
  bool m_decodedNoDisplaySEIEnabled {
    true
  };  // Enable(true)/disable(false) writing only pictures that get displayed based on the no display SEI message
  std::string m_colourRemapSEIFileName { "" };    // output Colour Remapping file name
  std::string m_SEICTIFileName { "" };    // output Recon with CTI file name
  std::string m_SEIFGSFileName { "" };    // output file name for reconstructed sequence with film grain
  std::string m_annotatedRegionsSEIFileName { "" };    // annotated regions file name
  std::vector<int>
    m_targetDecLayerIdSet {};      // set of LayerIds to be included in the sub-bitstream extraction process.
  std::vector<int> m_targetOutputLayerIdSet {};      // set of LayerIds to be outputted
  std::string      m_outputDecodedSEIMessagesFilename {
    ""
  }; // filename to output decoded SEI messages to. If '-', then use stdout. If empty, do not output details.
#if JVET_S0257_DUMP_360SEI_MESSAGE
  std::string m_outputDecoded360SEIMessagesFilename { "" }; // filename to output decoded 360 SEI messages to.
#endif
#if JVET_Z0120_SII_SEI_PROCESSING
  std::string m_shutterIntervalPostFileName { "" };    // output Post Filtering file name
#endif
  bool m_clipOutputVideoToRec709Range { false }; // If true, clip the output video to the Rec 709 range on saving.
  bool m_packedYUVMode {
    false
  }; // If true, output 10-bit and 12-bit YUV data as 5-byte and 3-byte (respectively) packed YUV data
  std::string m_cacheCfgFile { "" };    // Config file of cache model
  int         m_statMode { 3 };     // Config statistic mode (0 - bit stat, 1 - tool stat, 3 - both)
  bool        m_mctsCheck { false };
  int m_upscaledOutput { 2 };   // Output upscaled (2), decoded but in full resolution buffer (1) or decoded cropped (0,
                                // default) picture for RPR.
  int m_upscaleFilterForDisplay { 1 };
  int m_targetSubPicIdx { 0 };   // Specify which subpicture shall be write to output, using subpicture index
#if GEOMOTION_ENABLE
  std::string m_geomRecFolder {};
  std::string m_geomMode {};
#endif
#if ENABLE_CABAC_DUMP
  bool m_activateDump { false };
#endif
#if ENABLE_NNLF
  std::string m_nnlfModelName { "" };   // NNLF model file name
  int         m_nnlfDebugOption {
    0
  };   // NNLF debug option: 0: default, 1: apply only on I slice, 2: apply on all slices using I type as input
  std::string m_nnlfDumpBasename { "" };   // Basename for NNLF data dumping
#endif
};

//! \}

#endif   // __DECAPPCFG__
