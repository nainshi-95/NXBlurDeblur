from __future__ import annotations

import argparse
import math
import re
import shlex
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable, List, Sequence


FILENAME_RE = re.compile(
    r"^(?P<seq_name>.+)_(?P<width>\d+)x(?P<height>\d+)(?:_(?P<extra>.+))?\.yuv$"
)


@dataclass(frozen=True)
class SequenceItem:
    seq_name: str
    width: int
    height: int
    extra_info: str
    yuv_path: Path


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(
        description="Submit BVI-DVC YUV encodes to bsub in batches of 8 commands."
    )
    parser.add_argument(
        "--dataset_dir",
        type=str,
        required=True,
        help="Folder containing BVI-DVC YUV files.",
    )
    parser.add_argument(
        "--bin_path",
        type=str,
        default="bin/EncoderAppStaticd",
        help="Encoder executable path.",
    )
    parser.add_argument(
        "--cfg",
        type=str,
        default="cfg/encoder_randomaccess_nx2.cfg",
        help="Encoder config path.",
    )
    parser.add_argument(
        "--output_root",
        type=str,
        default="submit_outputs",
        help="Root folder for bin/rec/log/dump outputs.",
    )
    parser.add_argument(
        "--qps",
        type=str,
        default="22,27,32,37",
        help='Comma-separated QPs. Default: "22,27,32,37".',
    )
    parser.add_argument(
        "--frames",
        type=int,
        default=64,
        help="Always encode this many frames per sequence. Default: 64.",
    )
    parser.add_argument(
        "--frame_rate",
        type=int,
        default=30,
        help="Frame rate passed to the encoder. Default: 30.",
    )
    parser.add_argument(
        "--input_bit_depth",
        type=int,
        default=10,
        help="Input bit depth. BVI-DVC is assumed 10-bit. Default: 10.",
    )
    parser.add_argument(
        "--batch_size",
        type=int,
        default=8,
        help="Number of encoder commands per bsub submission. Default: 8.",
    )
    parser.add_argument(
        "--job_prefix",
        type=str,
        default="BVI_DVC",
        help="bsub job name prefix.",
    )
    parser.add_argument(
        "--queue",
        type=str,
        default="",
        help="Optional bsub queue name.",
    )
    parser.add_argument(
        "--extra_bsub_args",
        type=str,
        default="",
        help='Extra arguments appended to bsub, e.g. \'-n 8 -R "span[hosts=1]"\'',
    )
    parser.add_argument(
        "--submit_bsub",
        action="store_true",
        help="Actually submit jobs. Without this, only print dry-run commands.",
    )
    return parser.parse_args()


def parse_qps(text: str) -> List[int]:
    qps = [int(token.strip()) for token in text.split(",") if token.strip()]
    if not qps:
        raise ValueError("At least one QP is required.")
    return qps


def discover_sequences(dataset_dir: Path) -> List[SequenceItem]:
    if not dataset_dir.is_dir():
        raise FileNotFoundError(f"Dataset directory not found: {dataset_dir}")

    items: List[SequenceItem] = []
    for yuv_path in sorted(dataset_dir.glob("*.yuv")):
        match = FILENAME_RE.match(yuv_path.name)
        if match is None:
            raise ValueError(
                "Failed to parse filename. Expected seqName_widthxheight_otherInfo.yuv: "
                f"{yuv_path.name}"
            )

        seq_name = match.group("seq_name")
        width = int(match.group("width"))
        height = int(match.group("height"))
        extra_info = match.group("extra") or ""

        items.append(
            SequenceItem(
                seq_name=seq_name,
                width=width,
                height=height,
                extra_info=extra_info,
                yuv_path=yuv_path.resolve(),
            )
        )

    if not items:
        raise FileNotFoundError(f"No .yuv files found in {dataset_dir}")

    return items


def sanitize_name(text: str) -> str:
    sanitized = re.sub(r"[^0-9A-Za-z._-]+", "_", text.strip())
    return sanitized.strip("._") or "seq"


def build_output_paths(
    output_root: Path,
    seq: SequenceItem,
    qp: int,
) -> tuple[Path, Path, Path, Path]:
    seq_tag = sanitize_name(seq.seq_name)
    extra_tag = sanitize_name(seq.extra_info) if seq.extra_info else "clip"
    stem = f"{seq_tag}_{seq.width}x{seq.height}_{extra_tag}_qp{qp:02d}"

    bitstream_path = output_root / f"qp{qp:02d}" / "bin" / f"{stem}.bin"
    recon_path = output_root / f"qp{qp:02d}" / "rec" / f"{stem}.yuv"
    log_path = output_root / f"qp{qp:02d}" / "log" / f"{stem}.log"
    dump_dir = output_root / f"qp{qp:02d}" / "dump" / stem

    bitstream_path.parent.mkdir(parents=True, exist_ok=True)
    recon_path.parent.mkdir(parents=True, exist_ok=True)
    log_path.parent.mkdir(parents=True, exist_ok=True)
    dump_dir.mkdir(parents=True, exist_ok=True)
    return bitstream_path, recon_path, log_path, dump_dir


def quote_cmd(parts: Sequence[str]) -> str:
    return " ".join(shlex.quote(part) for part in parts)


def build_encoder_cmd(
    bin_path: Path,
    cfg_path: Path,
    seq: SequenceItem,
    qp: int,
    frames: int,
    frame_rate: int,
    input_bit_depth: int,
    output_root: Path,
) -> str:
    bitstream_path, recon_path, log_path, dump_dir = build_output_paths(output_root, seq, qp)
    cmd_parts = [
        "env",
        f"NX_TRAINING_DUMP_DIR={dump_dir}",
        str(bin_path),
        "-c",
        str(cfg_path),
        "-i",
        str(seq.yuv_path),
        "-b",
        str(bitstream_path),
        "-o",
        str(recon_path),
        "-wdt",
        str(seq.width),
        "-hgt",
        str(seq.height),
        "--InputBitDepth=" + str(input_bit_depth),
        "--FrameRate=" + str(frame_rate),
        "--FramesToBeEncoded=" + str(frames),
        "--QP=" + str(qp),
    ]
    return f"{quote_cmd(cmd_parts)} > {shlex.quote(str(log_path))} 2>&1"


def chunked(items: Sequence[str], batch_size: int) -> Iterable[List[str]]:
    for start in range(0, len(items), batch_size):
        yield list(items[start:start + batch_size])


def submit_bsub_batch(
    cmds: Sequence[str],
    job_name: str,
    queue: str,
    extra_bsub_args: str,
    dry_run: bool,
) -> None:
    if not cmds:
        return

    body = " ".join(f"({cmd})&" for cmd in cmds) + " wait"
    parts = ["bsub", "-J", job_name]
    if queue:
        parts.extend(["-q", queue])
    if extra_bsub_args.strip():
        parts.extend(shlex.split(extra_bsub_args))
    parts.append(body)

    print("[BSUB CMD]")
    print(" ".join(shlex.quote(part) for part in parts))

    if dry_run:
        return

    subprocess.run(parts, check=True)


def main() -> None:
    args = parse_args()

    dataset_dir = Path(args.dataset_dir).resolve()
    bin_path = Path(args.bin_path).resolve()
    cfg_path = Path(args.cfg).resolve()
    output_root = Path(args.output_root).resolve()

    if not bin_path.is_file():
        raise FileNotFoundError(f"Encoder binary not found: {bin_path}")
    if not cfg_path.is_file():
        raise FileNotFoundError(f"Encoder cfg not found: {cfg_path}")
    if args.batch_size <= 0:
        raise ValueError("batch_size must be positive.")

    qps = parse_qps(args.qps)
    sequences = discover_sequences(dataset_dir)
    output_root.mkdir(parents=True, exist_ok=True)

    all_cmds: List[str] = []
    for seq in sequences:
        for qp in qps:
            all_cmds.append(
                build_encoder_cmd(
                    bin_path=bin_path,
                    cfg_path=cfg_path,
                    seq=seq,
                    qp=qp,
                    frames=args.frames,
                    frame_rate=args.frame_rate,
                    input_bit_depth=args.input_bit_depth,
                    output_root=output_root,
                )
            )

    total_batches = math.ceil(len(all_cmds) / args.batch_size)
    print(f"[INFO] dataset_dir={dataset_dir}")
    print(f"[INFO] sequences={len(sequences)}")
    print(f"[INFO] qps={qps}")
    print(f"[INFO] total_encoder_commands={len(all_cmds)}")
    print(f"[INFO] batch_size={args.batch_size}")
    print(f"[INFO] total_bsub_jobs={total_batches}")
    print(f"[INFO] output_root={output_root}")

    for batch_idx, cmds in enumerate(chunked(all_cmds, args.batch_size)):
        job_name = f"{args.job_prefix}_{batch_idx:04d}"
        submit_bsub_batch(
            cmds=cmds,
            job_name=job_name,
            queue=args.queue,
            extra_bsub_args=args.extra_bsub_args,
            dry_run=not args.submit_bsub,
        )

    if args.submit_bsub:
        print(f"[INFO] submitted {total_batches} bsub jobs")
    else:
        print(f"[INFO] dry-run complete: generated {total_batches} bsub jobs")


if __name__ == "__main__":
    main()
