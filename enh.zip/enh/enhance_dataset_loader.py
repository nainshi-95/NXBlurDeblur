from __future__ import annotations

import random
import struct
import zlib
from dataclasses import dataclass
from pathlib import Path
from typing import Dict, Iterator, List, Optional, Sequence, Tuple

import torch
from torch.utils.data import BatchSampler, DataLoader, Dataset, Sampler



def _parse_size_name(size_name: str) -> Tuple[int, int]:
    width_text, height_text = size_name.split("x", 1)
    return int(width_text), int(height_text)


def _paeth_predictor(a: int, b: int, c: int) -> int:
    p = a + b - c
    pa = abs(p - a)
    pb = abs(p - b)
    pc = abs(p - c)
    if pa <= pb and pa <= pc:
        return a
    if pb <= pc:
        return b
    return c


def read_gray_png(path: Path) -> Tuple[List[int], int, int, int]:
    data = path.read_bytes()
    if data[:8] != b"\x89PNG\r\n\x1a\n":
        raise ValueError(f"Not a PNG file: {path}")

    offset = 8
    width = height = bit_depth = color_type = None
    idat_chunks = bytearray()

    while offset < len(data):
        if offset + 8 > len(data):
            raise ValueError(f"Corrupted PNG chunk header: {path}")
        chunk_len = int.from_bytes(data[offset:offset + 4], "big")
        offset += 4
        chunk_type = data[offset:offset + 4]
        offset += 4
        chunk_payload = data[offset:offset + chunk_len]
        offset += chunk_len
        offset += 4

        if chunk_type == b"IHDR":
          width, height, bit_depth, color_type, _, _, _ = struct.unpack(">IIBBBBB", chunk_payload)
        elif chunk_type == b"IDAT":
            idat_chunks.extend(chunk_payload)
        elif chunk_type == b"IEND":
            break

    if width is None or height is None or bit_depth is None or color_type is None:
        raise ValueError(f"Missing IHDR in PNG: {path}")
    if color_type != 0:
        raise ValueError(f"Only grayscale PNG is supported: {path}")
    if bit_depth not in (8, 16):
        raise ValueError(f"Only 8-bit or 16-bit PNG is supported: {path}")

    raw = zlib.decompress(bytes(idat_chunks))
    bytes_per_sample = 2 if bit_depth == 16 else 1
    row_stride = 1 + width * bytes_per_sample
    expected = row_stride * height
    if len(raw) != expected:
        raise ValueError(f"Unexpected decompressed size for {path}: {len(raw)} != {expected}")

    def sample_at(row: bytearray, sample_idx: int) -> int:
        pos = sample_idx * bytes_per_sample
        if bytes_per_sample == 1:
            return row[pos]
        return (row[pos] << 8) | row[pos + 1]

    def set_sample(row: bytearray, sample_idx: int, value: int) -> None:
        pos = sample_idx * bytes_per_sample
        if bytes_per_sample == 1:
            row[pos] = value & 0xFF
        else:
            row[pos] = (value >> 8) & 0xFF
            row[pos + 1] = value & 0xFF

    prev_row = bytearray(width * bytes_per_sample)
    values: List[int] = []

    for row_idx in range(height):
        row = bytearray(raw[row_idx * row_stride + 1:(row_idx + 1) * row_stride])
        filter_type = raw[row_idx * row_stride]

        if filter_type == 1:
            for x in range(width):
                left = sample_at(row, x - 1) if x > 0 else 0
                set_sample(row, x, sample_at(row, x) + left)
        elif filter_type == 2:
            for x in range(width):
                up = sample_at(prev_row, x)
                set_sample(row, x, sample_at(row, x) + up)
        elif filter_type == 3:
            for x in range(width):
                left = sample_at(row, x - 1) if x > 0 else 0
                up = sample_at(prev_row, x)
                set_sample(row, x, sample_at(row, x) + ((left + up) >> 1))
        elif filter_type == 4:
            for x in range(width):
                left = sample_at(row, x - 1) if x > 0 else 0
                up = sample_at(prev_row, x)
                up_left = sample_at(prev_row, x - 1) if x > 0 else 0
                set_sample(row, x, sample_at(row, x) + _paeth_predictor(left, up, up_left))
        elif filter_type != 0:
            raise ValueError(f"Unsupported PNG filter type {filter_type} in {path}")

        for x in range(width):
            values.append(sample_at(row, x))
        prev_row = row

    return values, width, height, bit_depth


def _zeros_2d(height: int, width: int) -> List[List[int]]:
    return [[0 for _ in range(width)] for _ in range(height)]


def _reshape_2d(values: Sequence[int], width: int, height: int) -> List[List[int]]:
    return [list(values[row * width:(row + 1) * width]) for row in range(height)]


def _to_tensor_or_list(values: Sequence[int], width: int, height: int):
    grid = _reshape_2d(values, width, height)
    return torch.tensor(grid, dtype=torch.int32).unsqueeze(0)


def _append_be32(dst: bytearray, value: int) -> None:
    dst.extend(int(value).to_bytes(4, "big", signed=False))


def _crc32(data: bytes) -> int:
    return zlib.crc32(data) & 0xFFFFFFFF


def write_gray_png_8bit(path: Path, image_2d: Sequence[Sequence[int]]) -> None:
    height = len(image_2d)
    width = len(image_2d[0]) if height > 0 else 0
    if width <= 0 or height <= 0:
        raise ValueError(f"Invalid preview image size for {path}: {(width, height)}")

    raw = bytearray()
    for row in image_2d:
        if len(row) != width:
            raise ValueError(f"Inconsistent row width while writing {path}")
        raw.append(0)
        raw.extend(max(0, min(255, int(v))) for v in row)

    compressed = zlib.compress(bytes(raw))
    png = bytearray(b"\x89PNG\r\n\x1a\n")

    ihdr = bytearray()
    _append_be32(ihdr, width)
    _append_be32(ihdr, height)
    ihdr.extend([8, 0, 0, 0, 0])

    for chunk_type, payload in ((b"IHDR", ihdr), (b"IDAT", compressed), (b"IEND", b"")):
        _append_be32(png, len(payload))
        png.extend(chunk_type)
        png.extend(payload)
        _append_be32(png, _crc32(chunk_type + payload))

    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(bytes(png))


def tensor_to_preview_8bit(tensor: torch.Tensor) -> List[List[int]]:
    tensor_2d = tensor.detach().cpu().to(torch.int32)
    if tensor_2d.ndim != 2:
        raise ValueError(f"Expected 2D tensor for preview, got shape {tuple(tensor_2d.shape)}")

    preview = ((tensor_2d.clamp(0, 1023) * 255 + 511) // 1023).to(torch.uint8)
    return preview.tolist()


def save_batch_previews(batch: dict, preview_root: str | Path = "/tmp/enhance_loader_preview",
                        batch_idx: int = 0, sample_idx: int = 0) -> List[Path]:
    root = Path(preview_root)
    sample_name = Path(batch["name"][sample_idx]).stem
    prefix = f"batch{batch_idx:03d}_{sample_name}"

    outputs = {
        "gt": batch["gt"][sample_idx, 0],
        "recon": batch["recon"][sample_idx, 0],
        "prior1": batch["prior1"][sample_idx, 0],
        "prior2": batch["prior2"][sample_idx, 0],
    }

    saved_paths: List[Path] = []
    for key, tensor in outputs.items():
        out_path = root / key / f"{prefix}.png"
        write_gray_png_8bit(out_path, tensor_to_preview_8bit(tensor))
        saved_paths.append(out_path)

    return saved_paths


@dataclass(frozen=True)
class SampleRecord:
    size_name: str
    cu_width: int
    cu_height: int
    name: str
    gt_path: Path
    recon_path: Path
    prior1_path: Optional[Path]
    prior2_path: Optional[Path]


class EnhanceDataset(Dataset):
    def __init__(self, root: str | Path = "dataset_dump", skip_missing_both_priors: bool = False) -> None:
        self.root = Path(root)
        self.gt_root = self.root / "gt"
        self.recon_root = self.root / "recon"
        self.prior1_root = self.root / "prior1"
        self.prior2_root = self.root / "prior2"
        self.skip_missing_both_priors = skip_missing_both_priors

        if not self.gt_root.is_dir():
            raise FileNotFoundError(f"gt folder not found: {self.gt_root}")

        self.samples: List[SampleRecord] = []
        self.indices_by_size: Dict[str, List[int]] = {}
        self.skipped_missing_both_priors: List[str] = []
        self._build_index()

    def _build_index(self) -> None:
        for size_dir in sorted(self.gt_root.iterdir()):
            if not size_dir.is_dir():
                continue

            size_name = size_dir.name
            cu_width, cu_height = _parse_size_name(size_name)
            recon_dir = self.recon_root / size_name
            prior1_dir = self.prior1_root / size_name
            prior2_dir = self.prior2_root / size_name

            for gt_path in sorted(size_dir.glob("*.png")):
                recon_path = recon_dir / gt_path.name
                if not recon_path.is_file():
                    raise FileNotFoundError(f"Missing recon for {gt_path.name}: {recon_path}")

                prior1_path = prior1_dir / gt_path.name
                prior2_path = prior2_dir / gt_path.name
                prior1 = prior1_path if prior1_path.is_file() else None
                prior2 = prior2_path if prior2_path.is_file() else None
                if prior1 is None and prior2 is None:
                    if self.skip_missing_both_priors:
                        self.skipped_missing_both_priors.append(str(gt_path.relative_to(self.gt_root)))
                        continue
                    raise RuntimeError(
                        f"Both prior1 and prior2 are missing for {gt_path.name}. "
                        "This usually means the dataset dump in C++ is wrong."
                    )

                record = SampleRecord(
                    size_name=size_name,
                    cu_width=cu_width,
                    cu_height=cu_height,
                    name=gt_path.name,
                    gt_path=gt_path,
                    recon_path=recon_path,
                    prior1_path=prior1,
                    prior2_path=prior2,
                )
                sample_idx = len(self.samples)
                self.samples.append(record)
                self.indices_by_size.setdefault(size_name, []).append(sample_idx)

    def __len__(self) -> int:
        return len(self.samples)

    def _load_and_check(self, path: Path, expected_width: int, expected_height: int) -> Sequence[int]:
        values, width, height, _ = read_gray_png(path)
        if width != expected_width or height != expected_height:
            raise ValueError(
                f"Unexpected shape for {path}: {(width, height)} != {(expected_width, expected_height)}"
            )
        return values

    def __getitem__(self, index: int):
        record = self.samples[index]

        gt_values = self._load_and_check(record.gt_path, record.cu_width, record.cu_height)
        recon_values = self._load_and_check(record.recon_path, record.cu_width + 1, record.cu_height + 1)

        prior_width = record.cu_width + 2
        prior_height = record.cu_height + 2

        if record.prior1_path is not None:
            prior1_values = self._load_and_check(record.prior1_path, prior_width, prior_height)
        else:
            prior1_values = [0] * (prior_width * prior_height)

        if record.prior2_path is not None:
            prior2_values = self._load_and_check(record.prior2_path, prior_width, prior_height)
        else:
            prior2_values = [0] * (prior_width * prior_height)

        if max(prior1_values) == 0 and max(prior2_values) == 0:
            raise RuntimeError(
                f"Both priors are all-zero for {record.name}. "
                "If neither prior exists or both are empty, please check the C++ dump code."
            )

        sample = {
            "name": record.name,
            "size_name": record.size_name,
            "cu_width": record.cu_width,
            "cu_height": record.cu_height,
            "gt": _to_tensor_or_list(gt_values, record.cu_width, record.cu_height),
            "recon": _to_tensor_or_list(recon_values, record.cu_width + 1, record.cu_height + 1),
            "prior1": _to_tensor_or_list(prior1_values, prior_width, prior_height),
            "prior2": _to_tensor_or_list(prior2_values, prior_width, prior_height),
        }
        return sample


class SizeGroupedBatchSampler(BatchSampler):
    def __init__(self, indices_by_size: Dict[str, List[int]], batch_size: int, shuffle: bool = True,
                 drop_last: bool = False) -> None:
        self.indices_by_size = {key: list(value) for key, value in indices_by_size.items()}
        self.batch_size = batch_size
        self.shuffle = shuffle
        self.drop_last = drop_last

    def __iter__(self) -> Iterator[List[int]]:
        rng = random.Random()
        size_keys = list(self.indices_by_size.keys())
        if self.shuffle:
            rng.shuffle(size_keys)

        for size_key in size_keys:
            indices = list(self.indices_by_size[size_key])
            if self.shuffle:
                rng.shuffle(indices)

            for start in range(0, len(indices), self.batch_size):
                batch = indices[start:start + self.batch_size]
                if len(batch) < self.batch_size and self.drop_last:
                    continue
                yield batch

    def __len__(self) -> int:
        total = 0
        for indices in self.indices_by_size.values():
            full, rem = divmod(len(indices), self.batch_size)
            total += full
            if rem and not self.drop_last:
                total += 1
        return total


def collate_enhance_batch(samples: Sequence[dict]) -> dict:
    if not samples:
        raise ValueError("Empty batch")

    size_names = {sample["size_name"] for sample in samples}
    if len(size_names) != 1:
        raise RuntimeError(f"Mixed CU sizes in one batch: {sorted(size_names)}")
    
    return {
        "name": [sample["name"] for sample in samples],
        "size_name": samples[0]["size_name"],
        "cu_width": samples[0]["cu_width"],
        "cu_height": samples[0]["cu_height"],
        "gt": torch.stack([sample["gt"] for sample in samples], dim=0),
        "recon": torch.stack([sample["recon"] for sample in samples], dim=0),
        "prior1": torch.stack([sample["prior1"] for sample in samples], dim=0),
        "prior2": torch.stack([sample["prior2"] for sample in samples], dim=0),
    }


def create_dataloader(root: str | Path = "dataset_dump", batch_size: int = 4, shuffle: bool = True, drop_last: bool = False, num_workers: int = 0, skip_missing_both_priors: bool = False):
    dataset = EnhanceDataset(root, skip_missing_both_priors=skip_missing_both_priors)
    batch_sampler = SizeGroupedBatchSampler(
        indices_by_size=dataset.indices_by_size,
        batch_size=batch_size,
        shuffle=shuffle,
        drop_last=drop_last,
    )
    return DataLoader(
        dataset,
        batch_sampler=batch_sampler,
        num_workers=num_workers,
        collate_fn=collate_enhance_batch,
    )


def iter_grouped_batches(dataset: EnhanceDataset, batch_size: int, shuffle: bool = False,
                         drop_last: bool = False) -> Iterator[dict]:
    sampler = SizeGroupedBatchSampler(dataset.indices_by_size, batch_size=batch_size, shuffle=shuffle,
                                      drop_last=drop_last)
    for batch_indices in sampler:
        samples = [dataset[idx] for idx in batch_indices]
        yield collate_enhance_batch(samples)


def _tensor_like_stats(tensor_like) -> Tuple[int, int]:
    return int(tensor_like.min().item()), int(tensor_like.max().item())


def run_self_test(root: str | Path = "./dataset_dump", batch_size: int = 4,
                  skip_missing_both_priors: bool = False) -> None:
    dataset = EnhanceDataset(root, skip_missing_both_priors=skip_missing_both_priors)
    print(f"dataset_root={Path(root).resolve()}")
    print(f"num_samples={len(dataset)}")
    print(f"num_sizes={len(dataset.indices_by_size)}")
    print(f"skipped_missing_both_priors={len(dataset.skipped_missing_both_priors)}")
    if dataset.skipped_missing_both_priors:
        print(f"skipped_examples={dataset.skipped_missing_both_priors[:5]}")

    loader = create_dataloader(
        root=root,
        batch_size=batch_size,
        shuffle=True,
        drop_last=False,
        num_workers=0,
        skip_missing_both_priors=skip_missing_both_priors,
    )

    preview_root = Path("/tmp/enhance_loader_preview")
    saved_preview_paths: List[Path] = []

    for batch_idx, batch in enumerate(loader):
        print(f"batch_idx={batch_idx}")
        print(f"batch_size_name={batch['size_name']}")
        print(f"batch_count={len(batch['name'])}")
        print(f"gt_shape={tuple(batch['gt'].shape)}")
        print(f"recon_shape={tuple(batch['recon'].shape)}")
        print(f"prior1_shape={tuple(batch['prior1'].shape)}")
        print(f"prior2_shape={tuple(batch['prior2'].shape)}")

        test_idx = 0
        first_gt = batch["gt"][test_idx, 0]
        first_recon = batch["recon"][test_idx, 0]
        first_prior1 = batch["prior1"][test_idx, 0]
        first_prior2 = batch["prior2"][test_idx, 0]

        print(f"first_name={batch['name'][test_idx]}")
        print(f"gt_min_max={_tensor_like_stats(first_gt)}")
        print(f"recon_min_max={_tensor_like_stats(first_recon)}")
        print(f"prior1_min_max={_tensor_like_stats(first_prior1)}")
        print(f"prior2_min_max={_tensor_like_stats(first_prior2)}")

        saved_preview_paths.extend(
            save_batch_previews(batch, preview_root=preview_root, batch_idx=batch_idx, sample_idx=0)
        )

    if saved_preview_paths:
        print(f"preview_root={preview_root}")
        print("saved_previews=")
        for path in saved_preview_paths:
            print(path)

    print("self_test=ok")


if __name__ == "__main__":
    run_self_test()
